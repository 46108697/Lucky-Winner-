REMOVING PRIVATE KEYS FROM CLIENT (HIGH PRIORITY)
-----------------------------------------------
Our scan found service account private keys or private key blocks inside files that appear to be in client/public folders.
THIS IS A HIGH SECURITY RISK. Steps to fix:
1) Remove the private key block from any file in public/ or client-side code. A redacted copy is included in 'patched_files'.
2) Place the service account JSON on the server (never commit to repo, never place in public assets).
3) Load the service account when starting your server from an environment variable or secure filesystem location:

   // Node.js example (server-side only)
   const admin = require('firebase-admin');
   const serviceAccount = JSON.parse(process.env.SERVICE_ACCOUNT_JSON);
   admin.initializeApp({
     credential: admin.credential.cert(serviceAccount),
   });

4) Deploy server-side endpoints / Cloud Functions to perform privileged operations (settlement, bulk wallet updates).
5) Remove any client code that imports 'firebase-admin' or attempts admin-level operations.

If you want, I can help create a Cloud Function template to do settlement and wallet updates securely.
