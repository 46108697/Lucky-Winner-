// firebase_admin_initialization_example.ts
// Safe server-side Firebase Admin initialization for Node / Next.js (server-side only)
// Usage: Put your service-account info into environment variables (never commit JSON to repo).
// IMPORTANT: Ensure this file is only imported in server-side code (API routes, getServerSideProps, etc).

import admin from 'firebase-admin';

function getServiceAccountFromEnv() {
  // Option A: Full JSON stored in an env var (recommended for some CI systems)
  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    try {
      return JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
    } catch (e) {
      console.error('Invalid FIREBASE_SERVICE_ACCOUNT_JSON:', e.message);
    }
  }

  // Option B: Individual env vars (commonly used in hosting platforms)
  if (process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PROJECT_ID) {
    return {
      type: 'service_account',
      project_id: process.env.FIREBASE_PROJECT_ID,
      private_key: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
      client_email: process.env.FIREBASE_CLIENT_EMAIL,
    };
  }
  return null;
}

const serviceAccount = getServiceAccountFromEnv();

if (!serviceAccount) {
  // Do NOT initialize admin without credentials. This prevents unclear 500 errors.
  console.warn('No Firebase admin credentials found in env. Admin SDK will not be initialized.');
} else {
  try {
    if (!admin.apps.length) {
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount as any),
      });
      console.log('Firebase Admin initialized (server-side).');
    }
  } catch (err) {
    console.error('Failed to initialize Firebase Admin SDK:', err);
    // throw error so server start fails visibly with stack trace (helps debugging)
    throw err;
  }
}

export default admin;
