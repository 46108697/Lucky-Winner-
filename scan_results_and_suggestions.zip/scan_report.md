# Deep Scan Report
Generated: 2025-10-02T13:00:28.940527Z

## Summary
- Found 2 zip file(s): ['download (5).zip', 'download (6).zip']
- Extracted 'download (5).zip' -> '/mnt/data/extracted_uploads/download (5)'
- Extracted 'download (6).zip' -> '/mnt/data/extracted_uploads/download (6)'
- Issues found: 22 across 200 files. Breakdown by type: {'firebase_admin_usage': 3, 'process_env_used': 19}

---

## Findings (detailed)

### 1. firebase_admin_usage — `download (5)/src/package.json`
- File imports or references `firebase-admin`. Ensure this file is server-side (not served to clients). If this appears in `public/` or `.html`, move it to server.

### 2. process_env_used — `download (5)/src/app/layout.tsx`
- Environment variable usage detected: `NEXT_PUBLIC_APP_URL` in `download (5)/src/app/layout.tsx`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 3. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_API_KEY` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 4. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 5. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_PROJECT_ID` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 6. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 7. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 8. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_APP_ID` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 9. process_env_used — `download (5)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` in `download (5)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 10. firebase_admin_usage — `download (5)/src/lib/firebase/admin.ts`
- File imports or references `firebase-admin`. Ensure this file is server-side (not served to clients). If this appears in `public/` or `.html`, move it to server.

### 11. process_env_used — `download (5)/src/lib/firebase/admin.ts`
- Environment variable usage detected: `FIREBASE_PROJECT_ID` in `download (5)/src/lib/firebase/admin.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 12. process_env_used — `download (5)/src/lib/firebase/admin.ts`
- Environment variable usage detected: `FIREBASE_CLIENT_EMAIL` in `download (5)/src/lib/firebase/admin.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 13. process_env_used — `download (5)/src/lib/firebase/admin.ts`
- Environment variable usage detected: `FIREBASE_PRIVATE_KEY` in `download (5)/src/lib/firebase/admin.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 14. firebase_admin_usage — `download (6)/src/package.json`
- File imports or references `firebase-admin`. Ensure this file is server-side (not served to clients). If this appears in `public/` or `.html`, move it to server.

### 15. process_env_used — `download (6)/src/app/layout.tsx`
- Environment variable usage detected: `NEXT_PUBLIC_APP_URL` in `download (6)/src/app/layout.tsx`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 16. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_API_KEY` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 17. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 18. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_PROJECT_ID` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 19. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 20. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 21. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_APP_ID` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).
### 22. process_env_used — `download (6)/src/lib/firebase.ts`
- Environment variable usage detected: `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` in `download (6)/src/lib/firebase.ts`. Make sure env var is provided in deployment environment (e.g., via systemd, PM2, Docker env, or Cloud Functions).

---

## Prioritized Action Plan (Highest -> Lowest)

1. **Private keys in client files** — remove immediately. Move service account keys to server environment variables and deploy server-side admin logic.

2. **Ensure server `start` script and dependencies** — add `start` script in package.json, install dependencies (npm install), and verify `node index.js` (or your entry) runs locally.

3. **Fix `await` usage** — wrap in async functions or use IIFE. Top-level `await` requires Node >=14.8 with modules; otherwise use async functions.

4. **Improve error logging** — replace silent `res.status(500)` with logging to find root cause.

5. **Move settlement/wallet logic to server** — do not rely on client-side writes for critical financial updates.
